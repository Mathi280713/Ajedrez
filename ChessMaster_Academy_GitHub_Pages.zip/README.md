# ChessMaster Academy
PWA en español, preparada para GitHub Pages.

## Archivos
- `index.html`: aplicación completa; CSS, motor de reglas y lógica integrados.
- `sw.js`: caché offline.
- `manifest.webmanifest`: configuración instalable.
- `icons/`: SVG y PNG de 192 y 512 px.

## Publicar
1. Extraé el ZIP.
2. Subí todo el contenido a la raíz del repositorio (incluida `icons/`).
3. GitHub → Settings → Pages.
4. Elegí Deploy from a branch, rama `main`, carpeta `/ (root)` y guardá.
5. Abrí la URL publicada por GitHub Pages.

## Android
Abrí el sitio en Chrome → ⋮ → Instalar aplicación / Añadir a pantalla principal.

## Alcance actual
Tablero con movimientos legales, jaque, mate, ahogado, enroque, captura al paso y promoción; cinco niveles de rival local; deshacer, sugerencias y exportación de movimientos; lecciones, preguntas de táctica, aperturas, torneos individuales de práctica, estadísticas e historial.
El rival usa búsqueda local minimax con evaluación sencilla: no es Stockfish ni un motor profesional. Los torneos son simulaciones contra la computadora. No hay cuentas, multijugador ni sincronización en línea. El progreso se guarda localmente en el navegador.
